
import './App.css';
import API from "./components/api.js";



function App() {
  return (
    <div> 
      <API></API>
      
    </div>
  );
}

export default App;
