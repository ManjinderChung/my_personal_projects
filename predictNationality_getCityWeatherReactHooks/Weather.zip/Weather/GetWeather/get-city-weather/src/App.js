import './App.css';
import GetWeather from './components/inputCity.js'

function App() {
  return (
    <div>
      <GetWeather></GetWeather>
    </div>
  );
}

export default App;
