import React from "react";

// Component to show the current balance
function Balance({ balance }) {
  return <h1>Current Balance: £{balance}</h1>;
}

export default Balance;
